import sys
from PIL import Image
import os

# 输入图片的路径和输出文件夹的路径
input_image_path = sys.argv[1]
output_dir = sys.argv[2]

# 读取图片
image = Image.open(input_image_path)

# 对图片进行处理，这里只是一个示例，你可能需要根据你的需求进行修改
processed_image = image.convert('1')

# 保存处理后的图片到输出文件夹
output_image_path = os.path.join(output_dir, os.path.basename(input_image_path))
processed_image.save(output_image_path)
