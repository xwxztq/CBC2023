#!/bin/sh

# 第一个参数是输入文件，第二个参数是输出文件夹
input=$1
output_dir=$2

echo "input file: $input"
echo "output dir: $output_dir"
echo "Current dir: $(pwd)"

cat $input
ls /mounted/


# 遍历输入文件的每一行，读取图片路径
while IFS= read -r line
do
  # 使用python脚本处理图片并保存到输出目录
  echo $line
  python process_image.py "$line" "$output_dir"
done < "$input"
